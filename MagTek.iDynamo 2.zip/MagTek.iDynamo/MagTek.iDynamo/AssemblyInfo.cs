using System;
using ObjCRuntime;

//Frameworks = "AudioToolbox CoreGraphics ExternalAccessory AVFoundation"
//[assembly: LinkWith ("libMTSCRA.a",LinkTarget = LinkTarget.ArmV6 | LinkTarget.ArmV7 | LinkTarget.Simulator, ForceLoad = true, IsCxx = true)]
//[assembly: LinkWith("libMTSCRA.a", LinkTarget.Simulator | LinkTarget.Arm64 | LinkTarget.ArmV7 | LinkTarget.ArmV6 | LinkTarget.ArmV7s, "-lc++", Frameworks = "UIKit Foundation CoreGraphics", ForceLoad = false, IsCxx = true, SmartLink = true)]
[assembly: LinkWith("libMTSCRA.a", LinkTarget.ArmV7 | LinkTarget.ArmV7s | LinkTarget.Arm64 | LinkTarget.Simulator64 | LinkTarget.Simulator, Frameworks = "CoreData, SystemConfiguration, MobileCoreServices, Foundation, CoreLocation, Security", SmartLink = true, ForceLoad = true)]
